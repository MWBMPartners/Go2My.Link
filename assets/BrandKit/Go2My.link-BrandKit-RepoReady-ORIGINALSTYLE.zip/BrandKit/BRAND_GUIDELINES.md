<!--
File: /BrandKit/BRAND_GUIDELINES.md
Purpose: Practical brand usage rules
(C) 2025–present MWBM Partners Ltd (d/b/a MW Services)
Version: 1.1
-->

# Brand Guidelines ✅

Use `logos/svg/Go2My.link-Logo-Vector.svg` as the default.
Use `logos/svg/Go2My.link-Logo-Glass.svg` for marketing.
Use `logos/animated/Go2My.link-Logo-AutoTheme.svg` for dark/light auto switching.
