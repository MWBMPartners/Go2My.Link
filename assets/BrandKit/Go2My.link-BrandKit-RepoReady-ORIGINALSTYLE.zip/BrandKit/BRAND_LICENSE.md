<!--
File: /BrandKit/BRAND_LICENSE.md
Purpose: License/ownership statement
(C) 2025–present MWBM Partners Ltd (d/b/a MW Services)
Version: 1.1
-->

(C) 2025–present MWBM Partners Ltd (d/b/a MW Services) — All rights reserved.
