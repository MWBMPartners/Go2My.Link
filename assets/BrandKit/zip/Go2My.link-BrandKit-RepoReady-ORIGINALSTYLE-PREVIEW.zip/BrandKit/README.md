<!--
File: /BrandKit/README.md
Purpose: Go2My.link branding assets (repo-ready)
(C) 2025–present MWBM Partners Ltd (d/b/a MW Services)
Version: 1.1
-->

# Go2My.link BrandKit 🔗✨

Premium angled-chain logo assets (transparent background) with variants, icons, PWA bundle, press kit and intro videos.

Quick picks:
- Primary: `logos/svg/Go2My.link-Logo-Vector.svg`
- Glass: `logos/svg/Go2My.link-Logo-Glass.svg`
- Auto theme: `logos/animated/Go2My.link-Logo-AutoTheme.svg`
- Optimized: `logos/optimized/Go2My.link-Logo-Optimized.svg`

Generated: 2026-02-22T23:49:34.477946Z
