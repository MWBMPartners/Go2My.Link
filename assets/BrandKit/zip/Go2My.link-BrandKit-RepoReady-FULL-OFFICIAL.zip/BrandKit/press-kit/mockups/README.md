# Place high-res device mockups here (Mac, iPhone, browser UI screenshots)
