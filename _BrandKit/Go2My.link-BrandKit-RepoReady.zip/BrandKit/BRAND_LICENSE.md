<!--
File: /BrandKit/BRAND_LICENSE.md
Purpose: License/ownership statement for the Go2My.link brand assets
(C) 2025–present MWBM Partners Ltd (d/b/a MW Services)
Version: 1.0
-->

# Brand License / Usage Notice

All logos, icons, mockups, and other brand assets in this folder are:

**(C) 2025–present MWBM Partners Ltd (d/b/a MW Services)**  
**All rights reserved.**

Permission is granted to use these assets only for official Go2My.link properties and marketing materials as authorised by MWBM Partners Ltd.

If you need broader permission (e.g., partners/press), create a written approval record and reference it in your repository or press workflow.
